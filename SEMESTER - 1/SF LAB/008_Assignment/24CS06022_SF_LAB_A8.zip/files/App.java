public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("\n\nEverything is fine, move forward!!!!!!");
    }
}
